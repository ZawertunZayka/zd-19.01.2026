# Zadanie 3 (Nauka): Pętla DO...WHILE - Walidacja

Ta pętla jest idealna, gdy chcemy o coś zapytać użytkownika **przynajmniej raz** i pytać ponownie, jeśli odpowiedź jest zła.

## Cel

Poproś użytkownika o podanie poprawnego hasła ("tajne"). Pytaj do skutku.

## Instrukcja krok po kroku

1.  Zadeklaruj zmienną `haslo`, ale nic do niej nie przypisuj.
    ```javascript
    let haslo;
    ```
2.  Rozpocznij blok `do`.
    ```javascript
    do {
        // To wykona się zawsze przynajmniej raz
    } ...
    ```
3.  Wewnątrz klamr przypisz do zmiennej `haslo` wynik funkcji `prompt()`.
    ```javascript
    haslo = prompt("Podaj hasło (spróbuj wpisać 'tajne'):");
    ```
4.  Po zamknięciu klamry `}` dopisz `while (warunek);`.
    - Warunek ma brzmieć: "dopóki hasło jest RÓŻNE od 'tajne'".
    - Operator "różne" to `!=`.
    ```javascript
    } while (haslo != "tajne");
    ```
5.  Za pętlą dodaj `alert("Brawo! Hasło poprawne.");`. Ten kod wykona się tylko wtedy, gdy pętla przestanie działać (czyli użytkownik wpisze "tajne").

## Czego się nauczyłeś?

- Że `do...while` wykonuje kod, a potem sprawdza warunek.
- Jak wymusić na użytkowniku podanie konkretnej wartości.
