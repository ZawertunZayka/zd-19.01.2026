let haslo;

// Tutaj wpisz konstrukcję do...while

do {
  haslo = prompt("Podaj hasło (spróbuj wpisać 'tajne'):");
} while (haslo != "tajne");

alert("Brawo! Hasło poprawne.");
