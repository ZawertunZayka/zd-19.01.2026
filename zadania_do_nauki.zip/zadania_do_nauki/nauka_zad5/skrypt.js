// Pętla for od 0 do 20
// Wewnątrz instrukcja if sprawdzająca parzystość (i % 2 == 0)

for (let i = 0; i <= 20; i++) {

    if (i % 2 == 0) {
      document.write(i + " ");
    }
  
  }
  