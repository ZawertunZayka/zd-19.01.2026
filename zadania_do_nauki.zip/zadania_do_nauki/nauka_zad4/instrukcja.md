# Zadanie 4 (Nauka): Sumowanie (Akumulacja)

To zadanie nauczy Cię, jak używać pętli do zbierania wyników (np. sumowania liczb).

## Cel

Obliczyć sumę liczb od 1 do wartości podanej przez użytkownika (np. dla 5: 1+2+3+4+5 = 15).

## Instrukcja krok po kroku

1.  Zapytaj użytkownika o liczbę `n` i zamień ją na typ liczbowy funkcją `parseInt()`.
    ```javascript
    let n = prompt("Podaj liczbę końcową:");
    n = parseInt(n);
    ```
2.  Stwórz zmienną `suma` i ustaw ją na **0**. To bardzo ważne - musimy mieć czystą kartkę przed dodawaniem.
    ```javascript
    let suma = 0;
    ```
3.  Uruchom pętlę `for` od `1` do `n` (włącznie).
4.  Wewnątrz pętli dodaj aktualny licznik `i` do zmiennej `suma`.
    ```javascript
    suma = suma + i;
    // Skrócony zapis: suma += i;
    ```
5.  **Poza pętlą** (po zamknięciu klamry `}`) wyświetl wynik. Gdybyś dał to w środku, wynik wyświetlałby się wielokrotnie!

## Czego się nauczyłeś?

- Co to jest "akumulator" (zmienna `suma` na zewnątrz pętli).
- Dlaczego ważne jest, gdzie umieścimy `alert`/`document.write` (w pętli vs po pętli).
