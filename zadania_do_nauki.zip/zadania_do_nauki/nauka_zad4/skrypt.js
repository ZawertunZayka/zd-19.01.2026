// Pobierz liczbę od użytkownika
// Zadeklaruj sumę
// Napisz pętlę for
// Wypisz wynik PO pętli

let n = prompt("Podaj liczbę końcową:");
let suma = 0;

for (let i = 1; i <= n; i++) {
  suma = suma + i;
}

document.write("Suma wynosi: " + suma);
