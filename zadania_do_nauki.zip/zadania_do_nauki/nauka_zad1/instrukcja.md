# Zadanie 1 (Nauka): Pętla FOR - Powitanie

To zadanie nauczy Cię, jak używać pętli `for` do wielokrotnego wykonania tej samej czynności.

## Cel

Wypisać na ekranie 10 razy zdanie "Programuję w JS!", numerując każdy wiersz.

## Instrukcja krok po kroku

1.  Otwórz plik `skrypt.js`.
2.  Stwórz pętlę `for`. Pętla `for` składa się z trzech części w nawiasie:
    - **Start**: `let i = 1` (zaczynamy liczenie od 1)
    - **Koniec**: `i <= 10` (pętla działa dopóki i jest mniejsze lub równe 10)
    - **Krok**: `i++` (zwiększamy i o 1 po każdym obiegu)
3.  Zapisz to tak:
    ```javascript
    for (let i = 1; i <= 10; i++) {
      // Tu wpiszemy kod do wykonania 10 razy
    }
    ```
4.  Wewnątrz klamr `{ }` użyj `document.write()`, aby wypisać tekst.
5.  Aby wyświetlić licznik, użyj zmiennej `i`. Aby przejść do nowej linii, dodaj `<br>`.
    - Przykład łączenia tekstu: `document.write(i + ". Przykładowy tekst<br>");`
6.  Zapisz plik i otwórz `index.html` w przeglądarce, aby sprawdzić działanie.

## Czego się nauczyłeś?

- Jak zapisać podstawową strukturę pętli `for`.
- Jak wykorzystać zmienną licznikową (`i`) wewnątrz pętli.
