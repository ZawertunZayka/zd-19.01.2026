// Miejsce na Twój kod
// Postępuj zgodnie z instrukcją w pliku instrukcja.md
for (let i = 1; i <= 10; i++) {
    document.write(i + ". Programuję w JS!<br>");
  }
  